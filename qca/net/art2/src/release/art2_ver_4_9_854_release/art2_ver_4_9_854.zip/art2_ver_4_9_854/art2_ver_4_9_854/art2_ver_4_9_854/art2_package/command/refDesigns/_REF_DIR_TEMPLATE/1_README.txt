Each of the files in this directory are required when 
creating a new reference design folder. If the design 
does not require one or more of these files, you will 
still need to create a file to act as a placeholder.